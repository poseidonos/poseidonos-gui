====================
Filesystem Utilities
====================

Various utilities for the local filesystem.

.. module:: werkzeug.filesystem

.. autoclass:: BrokenFilesystemWarning

.. autofunction:: get_filesystem_encoding
